// Updated main.js with Google Sheets integration
// DOM Elements
const signInBtn = document.getElementById('signInBtn');
const signInModal = document.getElementById('signInModal');
const registrationModal = document.getElementById('registrationModal');
const successModal = document.getElementById('successModal');
const emailForm = document.getElementById('emailForm');
const registrationForm = document.getElementById('registrationForm');
const closeButtons = document.querySelectorAll('.close');
const continueBtn = document.getElementById('continueBtn');
const vehicleTypeSelect = document.getElementById('vehicleType');
const rvFields = document.getElementById('rvFields');
const carFields = document.getElementById('carFields');
const trailerFields = document.getElementById('trailerFields');

// Google Apps Script Web App URL for form submission
const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxCzDdTtq_sgfRa3t3EFANXiNOwKDl_CtBqjrTy4e4GdYVK7SIqgR9WuJrEmmqZAMDf/exec";

// Simple user storage (would be replaced with server-side storage in production)
let users = JSON.parse(localStorage.getItem('crystalShipUsers')) || [];
let currentUser = JSON.parse(localStorage.getItem('crystalShipCurrentUser')) || null;

// Check if user is already signed in
document.addEventListener('DOMContentLoaded', function() {
    if (currentUser) {
        signInBtn.textContent = 'My Profile';
    }
    
    // Add global disclaimer
    addGlobalDisclaimer();
    
    // Set up vehicle type conditional fields
    setupVehicleFields();
});

// Open sign in modal
signInBtn.addEventListener('click', function(e) {
    e.preventDefault();
    
    if (currentUser) {
        // If user is signed in, redirect to profile page or show profile modal
        alert('Profile feature coming soon!');
        return;
    }
    
    signInModal.style.display = 'block';
});

// Close modals when clicking X
closeButtons.forEach(button => {
    button.addEventListener('click', function() {
        signInModal.style.display = 'none';
        registrationModal.style.display = 'none';
        successModal.style.display = 'none';
    });
});

// Close modals when clicking outside
window.addEventListener('click', function(e) {
    if (e.target === signInModal) {
        signInModal.style.display = 'none';
    }
    if (e.target === registrationModal) {
        registrationModal.style.display = 'none';
    }
    if (e.target === successModal) {
        successModal.style.display = 'none';
    }
});

// Handle email form submission
emailForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value.trim().toLowerCase();
    
    // Check if email exists in users array
    const existingUser = users.find(user => user.email === email);
    
    if (existingUser) {
        // Sign in existing user
        currentUser = existingUser;
        localStorage.setItem('crystalShipCurrentUser', JSON.stringify(currentUser));
        signInBtn.textContent = 'My Profile';
        signInModal.style.display = 'none';
        
        // Show success message
        successModal.querySelector('h2').textContent = 'Welcome Back!';
        successModal.querySelector('p').textContent = `You've successfully signed in as ${existingUser.fullName}.`;
        successModal.style.display = 'block';
    } else {
        // Prepare registration form for new user
        document.getElementById('regEmail').value = email;
        signInModal.style.display = 'none';
        registrationModal.style.display = 'block';
    }
});

// Set up vehicle type conditional fields
function setupVehicleFields() {
    vehicleTypeSelect.addEventListener('change', function() {
        // Hide all conditional fields first
        rvFields.style.display = 'none';
        carFields.style.display = 'none';
        trailerFields.style.display = 'none';
        
        // Show the appropriate fields based on selection
        const selectedValue = this.value;
        if (selectedValue === 'RV') {
            rvFields.style.display = 'block';
        } else if (selectedValue === 'Car') {
            carFields.style.display = 'block';
        } else if (selectedValue === 'Truck_Trailer') {
            trailerFields.style.display = 'block';
        }
    });
}

// Handle registration form submission
registrationForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(registrationForm);
    
    // Create base user data object
    const userData = {
        email: formData.get('email'),
        fullName: formData.get('fullName'),
        bmExperience: formData.get('bmExperience'),
        nameDrops: formData.get('nameDrops'),
        entryDate: formData.get('entryDate'),
        exitDate: formData.get('exitDate'),
        registrationDate: new Date().toISOString(),
        hasPaidDues: false
    };
    
    // Add vehicle information based on type
    const vehicleType = formData.get('vehicleType');
    userData.vehicleType = vehicleType;
    
    if (vehicleType === 'RV') {
        userData.vehicleDetails = {
            type: 'RV',
            length: formData.get('rvLength') + ' ft'
        };
    } else if (vehicleType === 'Car') {
        userData.vehicleDetails = {
            type: 'Car/SUV/Truck',
            make: formData.get('carMake'),
            year: formData.get('carYear'),
            model: formData.get('carModel')
        };
    } else if (vehicleType === 'Truck_Trailer') {
        userData.vehicleDetails = {
            type: 'Truck with Trailer',
            trailerSize: formData.get('trailerSize')
        };
    } else {
        userData.vehicleDetails = {
            type: 'None'
        };
    }
    
    // Add user to storage
    users.push(userData);
    localStorage.setItem('crystalShipUsers', JSON.stringify(users));
    
    // Set as current user
    currentUser = userData;
    localStorage.setItem('crystalShipCurrentUser', JSON.stringify(currentUser));
    signInBtn.textContent = 'My Profile';
    
    // Show loading indicator
    showNotification('Sending registration data...', 'info');
    
    // Send data to Google Sheets
    sendToGoogleSheets(formData)
        .then(response => {
            console.log('Google Sheets response:', response);
            showNotification('Registration data saved to Google Sheets!', 'success');
        })
        .catch(error => {
            console.error('Error saving to Google Sheets:', error);
            showNotification('Registration saved locally. Will sync to Google Sheets when connection is restored.', 'error');
            // Store in backup for later retry
            storeLocalBackup(formData);
        });
    
    // Show success message
    registrationModal.style.display = 'none';
    successModal.style.display = 'block';
});

// Continue button in success modal
continueBtn.addEventListener('click', function() {
    successModal.style.display = 'none';
});

// Add data disclaimer to all pages
function addGlobalDisclaimer() {
    const disclaimer = document.createElement('div');
    disclaimer.className = 'global-disclaimer';
    disclaimer.innerHTML = `
        <p><strong>IMPORTANT: Data Protection Notice</strong> - The Crystal Ship website does not provide data protection or security for any information you submit.</p>
    `;
    
    // Add styles for the disclaimer
    const style = document.createElement('style');
    style.textContent = `
        .global-disclaimer {
            background-color: rgba(255, 107, 107, 0.1);
            color: var(--text-color);
            text-align: center;
            padding: 0.5rem;
            font-size: 0.9rem;
        }
        .global-disclaimer p {
            margin: 0;
        }
        #notification {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 4px;
            font-weight: bold;
            z-index: 9999;
            transition: opacity 0.3s ease-in-out;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .info {
            background-color: rgba(0, 123, 255, 0.9);
            color: white;
        }
        .success {
            background-color: rgba(40, 167, 69, 0.9);
            color: white;
        }
        .error {
            background-color: rgba(220, 53, 69, 0.9);
            color: white;
        }
    `;
    
    document.head.appendChild(style);
    document.body.insertBefore(disclaimer, document.body.firstChild);
}

/**
 * Send registration data to Google Sheets
 * @param {FormData} formData - The registration form data
 * @return {Promise} Promise that resolves with the response
 */
function sendToGoogleSheets(formData) {
    // Format the data for Google Sheets
    const data = formatDataForSheets(formData);
    
    // Create request options
    const options = {
        method: 'POST',
        mode: 'no-cors', // This is important for cross-origin requests to Google Apps Script
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    };
    
    // Return promise for fetch request
    return fetch(GOOGLE_SCRIPT_URL, options)
        .then(response => {
            // Since we're using no-cors, we can't actually read the response
            // We'll assume success if the request doesn't throw an error
            return { success: true, message: "Data submitted successfully" };
        })
        .catch(error => {
            console.error('Error sending data to Google Sheets:', error);
            throw error;
        });
}

/**
 * Format form data for Google Sheets
 * @param {FormData} formData - The form data object
 * @return {Object} Formatted data object
 */
function formatDataForSheets(formData) {
    // Get current timestamp
    const timestamp = new Date().toISOString();
    
    // Create a data object from the form data
    const data = {
        timestamp: timestamp,
        email: formData.get('email'),
        fullName: formData.get('fullName'),
        bmExperience: formData.get('bmExperience'),
        nameDrops: formData.get('nameDrops'),
        vehicleType: formData.get('vehicleType'),
        entryDate: formData.get('entryDate'),
        exitDate: formData.get('exitDate')
    };
    
    // Format vehicle details as a single string for the sheet
    let vehicleDetails = "None";
    
    if (data.vehicleType === 'RV') {
        vehicleDetails = `RV - ${formData.get('rvLength')} ft`;
    } else if (data.vehicleType === 'Car') {
        vehicleDetails = `${formData.get('carYear')} ${formData.get('carMake')} ${formData.get('carModel')}`;
    } else if (data.vehicleType === 'Truck_Trailer') {
        vehicleDetails = `Truck with Trailer - ${formData.get('trailerSize')}`;
    }
    
    data.vehicleDetails = vehicleDetails;
    
    return data;
}

/**
 * Store registration data locally as backup
 * @param {FormData} formData - The form data object
 */
function storeLocalBackup(formData) {
    try {
        // Get existing backup data or initialize empty array
        const backupData = JSON.parse(localStorage.getItem('crystalShipBackupRegistrations')) || [];
        
        // Create a data object from the form data
        const data = {};
        for (const [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        // Add timestamp
        data.timestamp = new Date().toISOString();
        
        // Add to backup array
        backupData.push(data);
        
        // Store updated backup
        localStorage.setItem('crystalShipBackupRegistrations', JSON.stringify(backupData));
        
        console.log('Registration data backed up locally');
    } catch (error) {
        console.error('Error backing up registration data:', error);
    }
}

/**
 * Display a notification to the user
 * @param {String} message - The message to display
 * @param {String} type - The type of notification ('info', 'success', or 'error')
 */
function showNotification(message, type = 'info') {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'notification';
        document.body.appendChild(notification);
    }
    
    // Remove any existing classes
    notification.className = '';
    
    // Add the type class
    notification.classList.add(type);
    
    // Set message and show notification
    notification.textContent = message;
    notification.style.opacity = '1';
    
    // Hide after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
    }, 5000);
}

// Function to sign out (for future use)
function signOut() {
    currentUser = null;
    localStorage.removeItem('crystalShipCurrentUser');
    signInBtn.textContent = 'Sign In / Join';
}

// Function to retry sending backed up registrations (for future use)
function retrySendingBackupRegistrations() {
    const backupData = JSON.parse(localStorage.getItem('crystalShipBackupRegistrations')) || [];
    
    if (backupData.length === 0) {
        console.log('No backup registrations to send');
        return;
    }
    
    console.log(`Attempting to send ${backupData.length} backed up registrations`);
    
    // Process each backup entry
    const promises = backupData.map((entry, index) => {
        // Convert entry back to FormData
        const formData = new FormData();
        for (const [key, value] of Object.entries(entry)) {
            if (key !== 'timestamp') { // Skip the timestamp we added
                formData.append(key, value);
            }
        }
        
        // Send to Google Sheets
        return sendToGoogleSheets(formData)
            .then(() => {
                console.log(`Successfully sent backup registration ${index + 1}`);
                return index; // Return the index for successful ones
            })
            .catch(error => {
                console.error(`Failed to send backup registration ${index + 1}:`, error);
                return null; // Return null for failed ones
            });
    });
    
    // Process results
    Promise.all(promises)
        .then(results => {
            // Filter out the indices of successful sends
            const successfulIndices = results.filter(index => index !== null);
            
            // Remove successful entries from backup
            if (successfulIndices.length > 0) {
                const newBackupData = backupData.filter((_, index) => !successfulIndices.includes(index));
                localStorage.setItem('crystalShipBackupRegistrations', JSON.stringify(newBackupData));
                
                console.log(`Successfully sent ${successfulIndices.length} backed up registrations. ${newBackupData.length} remaining.`);
                
                if (newBackupData.length === 0) {
                    showNotification('All backed up registrations have been successfully sent to Google Sheets!', 'success');
                } else {
                    showNotification(`Sent ${successfulIndices.length} backed up registrations. ${newBackupData.length} remaining.`, 'info');
                }
            }
        });
}

// Try to send any backed up registrations when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Wait a bit to ensure the page is fully loaded
    setTimeout(() => {
        const backupData = JSON.parse(localStorage.getItem('crystalShipBackupRegistrations')) || [];
        if (backupData.length > 0) {
            console.log(`Found ${backupData.length} backed up registrations. Attempting to send...`);
            retrySendingBackupRegistrations();
        }
    }, 3000);
});
